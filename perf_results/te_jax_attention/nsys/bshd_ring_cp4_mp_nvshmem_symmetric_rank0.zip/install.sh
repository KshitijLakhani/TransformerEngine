#!/bin/bash
#
# Usage: ./install.sh [optional arguments to virtualenv]
#
# If it doesn't already exist, this creates a virtual environment named
# `nsys_jax_env` in the current directory and installs Jupyter Lab and the
# dependencies of the Analysis.ipynb notebook that is shipped alongside this
# script inside the output archives of the `nsys-jax` wrapper.
#
# The expectation is that those archives will be copied and extracted on a
# laptop or workstation, and this installation script will be run there, while
# the `nsys-jax` wrapper is executed on a remote GPU cluster.
set -ex
SCRIPT_DIR=$(cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd)
VIRTUALENV="${SCRIPT_DIR}/nsys_jax_venv"
BIN="${VIRTUALENV}/bin"
if [[ ! -d "${VIRTUALENV}" ]]; then
  # Let `virtualenv` find/choose a Python. Currently >=3.12 is supported.
  virtualenv -p 3.14 -p 3.13 -p 3.12 "$@" "${VIRTUALENV}"
  "${BIN}/pip" install -U pip
  "${BIN}/pip" install 'nsys-jax[jupyter] @ git+https://github.com/NVIDIA/JAX-Toolbox.git@418931326#subdirectory=.github/container/nsys_jax'
  "${BIN}/install-flamegraph" "${VIRTUALENV}"
  "${BIN}/install-protoc" "${VIRTUALENV}"
else
  echo "Virtual environment already exists, not installing anything..."
fi
# Pick up the current profile data by default
export NSYS_JAX_DEFAULT_PREFIX="${PWD}"
# https://setuptools.pypa.io/en/latest/userguide/datafiles.html#accessing-data-files-at-runtime
NOTEBOOK=$("${BIN}/python" -c 'from importlib.resources import files; print(files("nsys_jax") / "analyses" / "Analysis.ipynb")')
if [ -z ${NSYS_JAX_JUPYTER_EXECUTE_NOT_LAB+x} ]; then
  CMD="${BIN}/jupyter-lab"
else
  CMD="${BIN}/jupyter-execute"
fi
echo "Launching: cd ${SCRIPT_DIR} && ${CMD} ${NOTEBOOK}"
cd "${SCRIPT_DIR}" && "${CMD}" "${NOTEBOOK}"
